﻿using System.ComponentModel.DataAnnotations;

namespace ClientBookingApp.Models
{
    public enum EventType
    {
        Physical,
        Virtual
    }
    public enum BookingStatus
    {
        Pending,
        Confirmed,
        Cancelled
    }

    public class ClientBooking
    {
        public int BookingID { get; set; }

        public required string ClientName { get; set; }

        [Required]
        [EmailAddress]
        public required string Email { get; set; }

        [Required]
        [Phone]
        public required string Phone { get; set; }
        public EventType EventType { get; set; }

        [Required]
        public DateTime EventDate { get; set; }

        public required string EventDescription { get; set; }

        public required string EventName { get; set; }

        public DateTime BookingDate { get; set; }

        public BookingStatus BookingStatus { get; set; }
    }
    public class BookingStatusUpdate
    {
        [Required]
        public BookingStatus Status { get; set; }
    }

    public class EventBookingResponse
    {
        public int BookingID { get; set; }
        public string ClientName { get; set; } = "";
        public string Email { get; set; } = "";
        public string? Phone { get; set; }
        public string EventName { get; set; } = "";
        public string EventType { get; set; } = "Physical";
        public DateTime EventDate { get; set; }
        public string? EventDescription { get; set; }
        public int? NumOfPax { get; set; }
        public string? EventLocation { get; set; }
        public string? AssignedPIC { get; set; }
    }
    public class EventBookingUpdate
    {
        public string? EventName { get; set; }
        public string? EventType { get; set; }
        public DateTime EventDate { get; set; }
        public string? EventDescription { get; set; }
        public int? NumOfPax { get; set; }
        public string? EventLocation { get; set; }
        public string? AssignedPIC { get; set; }
    }

    public class LoginRequest
    {
        public required string Username { get; set; }
        public required string Password { get; set; }
    }

    public class LoginResponse
    {
        public bool Success { get; set; }
        public string? Role { get; set; }
        public required string Message { get; set; }
    }

}
