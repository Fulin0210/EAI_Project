﻿namespace ClientBookingApp.Models
{
    public class Response
    {

        public int statusCode {  get; set; }
        public required string statusMessage { get; set; }
    }
}
