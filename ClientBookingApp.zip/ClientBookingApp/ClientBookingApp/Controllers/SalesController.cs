﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ClientBookingApp.Models;
using System.Data;

namespace BookingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalesController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public SalesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        //Update
        [HttpPut("update-status/{bookingId}")]
        public IActionResult UpdateBookingStatus(int bookingId, [FromBody] BookingStatusUpdate update)
        {
            using var con = new SqlConnection(_configuration.GetConnectionString("ATAGCons"));
            con.Open();

            var cmd = new SqlCommand("UPDATE ClientBooking SET BookingStatus = @Status WHERE BookingID = @ID", con);
            cmd.Parameters.AddWithValue("@Status", update.Status.ToString());
            cmd.Parameters.AddWithValue("@ID", bookingId);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Status updated.") : NotFound("Booking not found.");
        }

        //Cancel booking
        [HttpDelete("cancel/{bookingId}")]
        public IActionResult CancelBooking(int bookingId)
        {
            try
            {
                using var con = new SqlConnection(_configuration.GetConnectionString("ATAGCons"));
                con.Open();

                var cmd = new SqlCommand("DELETE FROM ClientBooking WHERE BookingID = @ID", con);
                cmd.Parameters.AddWithValue("@ID", bookingId);

                int rows = cmd.ExecuteNonQuery();
                return rows > 0 ? Ok("Booking cancelled.") : NotFound("Booking ID not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error cancelling booking: " + ex.Message);
            }
        }

        [HttpPost("confirm")]
        public IActionResult ConfirmBooking([FromBody] ClientBooking booking)
        {
            try
            {
                using var con = new SqlConnection(_configuration.GetConnectionString("ATAGCons"));
                con.Open();

                var cmd = new SqlCommand(@"
            INSERT INTO EventBooking 
            (BookingID, ClientName, Email, Phone, EventName, EventType, EventDate, EventDescription, NumOfPax, EventLocation, AssignedPIC)
            VALUES 
            (@BookingID, @ClientName, @Email, @Phone, @EventName, @EventType, @EventDate, @EventDescription, @NumOfPax, @EventLocation, @AssignedPIC)", con);

                cmd.Parameters.AddWithValue("@BookingID", booking.BookingID);
                cmd.Parameters.AddWithValue("@ClientName", booking.ClientName);
                cmd.Parameters.AddWithValue("@Email", booking.Email);
                cmd.Parameters.AddWithValue("@Phone", string.IsNullOrEmpty(booking.Phone) ? DBNull.Value : booking.Phone);
                cmd.Parameters.AddWithValue("@EventName", booking.EventName);
                cmd.Parameters.AddWithValue("@EventType", booking.EventType.ToString());
                cmd.Parameters.AddWithValue("@EventDate", booking.EventDate);
                cmd.Parameters.AddWithValue("@EventDescription", string.IsNullOrEmpty(booking.EventDescription) ? DBNull.Value : booking.EventDescription);
                cmd.Parameters.AddWithValue("@NumOfPax", DBNull.Value);
                cmd.Parameters.AddWithValue("@EventLocation", DBNull.Value);
                cmd.Parameters.AddWithValue("@AssignedPIC", DBNull.Value);

                int rows = cmd.ExecuteNonQuery();
                return rows > 0 ? Ok("Booking confirmed.") : BadRequest("Insert failed: no rows affected.");
            }
            catch (Exception ex)
            {
                return BadRequest("Exception: " + ex.Message);
            }
        }
    }
}
