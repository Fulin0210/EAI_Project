﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ClientBookingApp.Models;
using System.Data;

namespace BookingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CalendarViewController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public CalendarViewController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet("bookings")]
        public IActionResult GetBookings([FromQuery] string role)
        {
            var bookings = new List<ClientBooking>();
            string connectionString = _configuration.GetConnectionString("ATAGCons");

            string query;

            if (role.Equals("Operations", StringComparison.OrdinalIgnoreCase))
            {
                // Confirmed bookings from EventBooking
                query = @"
                    SELECT BookingID, ClientName, Email, Phone, EventName, EventType, EventDate,
                           EventDescription, NumOfPax, EventLocation, AssignedPIC, ConfirmedDate
                    FROM EventBooking";
            }
            else
            {
                // All bookings from ClientBooking
                query = @"
                    SELECT BookingID, ClientName, Email, Phone, EventType, EventDate, 
                           EventDescription, EventName, BookingDate, BookingStatus
                    FROM ClientBooking";
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var booking = new ClientBooking
                        {
                            BookingID = reader.GetInt32(reader.GetOrdinal("BookingID")),
                            ClientName = reader.GetString(reader.GetOrdinal("ClientName")),
                            Email = reader.GetString(reader.GetOrdinal("Email")),
                            Phone = reader.IsDBNull(reader.GetOrdinal("Phone")) ? null : reader.GetString(reader.GetOrdinal("Phone")),
                            EventType = Enum.Parse<EventType>(reader.GetString(reader.GetOrdinal("EventType")), true),
                            EventDate = reader.GetDateTime(reader.GetOrdinal("EventDate")),
                            EventDescription = reader.IsDBNull(reader.GetOrdinal("EventDescription")) ? null : reader.GetString(reader.GetOrdinal("EventDescription")),
                            EventName = reader.GetString(reader.GetOrdinal("EventName"))
                        };

                        if (role.Equals("Operations", StringComparison.OrdinalIgnoreCase))
                        {
                            booking.BookingDate = reader.GetDateTime(reader.GetOrdinal("ConfirmedDate"));
                            booking.BookingStatus = BookingStatus.Confirmed;
                        }
                        else
                        {
                            booking.BookingDate = reader.GetDateTime(reader.GetOrdinal("BookingDate"));
                            booking.BookingStatus = Enum.Parse<BookingStatus>(reader.GetString(reader.GetOrdinal("BookingStatus")), true);
                        }

                        bookings.Add(booking);
                    }
                }
            }

            return Ok(bookings);
        }
    }
}
