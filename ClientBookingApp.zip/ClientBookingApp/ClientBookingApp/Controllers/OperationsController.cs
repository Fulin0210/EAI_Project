﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using ClientBookingApp.Models;

namespace BookingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OperationsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public OperationsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET: api/operations/eventbooking/{bookingId}
        [HttpGet("eventbooking/{bookingId}")]
        public IActionResult GetEventBooking(int bookingId)
        {
            using var con = new SqlConnection(_configuration.GetConnectionString("ATAGCons"));
            string query = @"SELECT BookingID, ClientName, Email, Phone, EventName, EventType, EventDate, EventDescription,
                                    NumOfPax, EventLocation, AssignedPIC
                             FROM EventBooking
                             WHERE BookingID = @BookingID";

            using var cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@BookingID", bookingId);
            con.Open();

            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) return NotFound("Booking not found.");

            var result = new
            {
                BookingID = (int)reader["BookingID"],
                ClientName = reader["ClientName"].ToString(),
                Email = reader["Email"].ToString(),
                Phone = reader["Phone"] == DBNull.Value ? null : reader["Phone"].ToString(),
                EventName = reader["EventName"].ToString(),
                EventType = reader["EventType"].ToString(),
                EventDate = Convert.ToDateTime(reader["EventDate"]),
                EventDescription = reader["EventDescription"] == DBNull.Value ? null : reader["EventDescription"].ToString(),
                NumOfPax = reader["NumOfPax"] == DBNull.Value ? null : (int?)Convert.ToInt32(reader["NumOfPax"]),
                EventLocation = reader["EventLocation"] == DBNull.Value ? null : reader["EventLocation"].ToString(),
                AssignedPIC = reader["AssignedPIC"] == DBNull.Value ? null : reader["AssignedPIC"].ToString()
            };

            return Ok(result);
        }

        [HttpPut("updatebooking/{bookingId}")]
        public IActionResult UpdateEventBooking(int bookingId, [FromBody] EventBookingUpdate updated)
        {
            using var con = new SqlConnection(_configuration.GetConnectionString("ATAGCons"));
            string update = @"
                UPDATE EventBooking SET
                    EventName = @EventName,
                    EventType = @EventType,
                    EventDate = @EventDate,
                    EventDescription = @EventDescription,
                    NumOfPax = @NumOfPax,
                    EventLocation = @EventLocation,
                    AssignedPIC = @AssignedPIC
                WHERE BookingID = @BookingID";

            using var cmd = new SqlCommand(update, con);
            cmd.Parameters.AddWithValue("@EventName", updated.EventName);
            cmd.Parameters.AddWithValue("@EventType", updated.EventType);
            cmd.Parameters.AddWithValue("@EventDate", updated.EventDate);
            cmd.Parameters.AddWithValue("@EventDescription", string.IsNullOrWhiteSpace(updated.EventDescription) ? DBNull.Value : updated.EventDescription);
            cmd.Parameters.AddWithValue("@NumOfPax", updated.NumOfPax.HasValue ? updated.NumOfPax.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@EventLocation", string.IsNullOrWhiteSpace(updated.EventLocation) ? DBNull.Value : updated.EventLocation);
            cmd.Parameters.AddWithValue("@AssignedPIC", string.IsNullOrWhiteSpace(updated.AssignedPIC) ? DBNull.Value : updated.AssignedPIC);
            cmd.Parameters.AddWithValue("@BookingID", bookingId);

            con.Open();
            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Updated successfully.") : NotFound("Booking ID not found.");
        }

    }
}
