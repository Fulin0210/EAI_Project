﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ClientBookingApp.Models;

namespace BookingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public UsersController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new LoginResponse
                {
                    Success = false,
                    Role = null,
                    Message = "Username and password are required."
                });
            }

            string connectionString = _configuration.GetConnectionString("ATAGCons");
            string query = "SELECT Role FROM Users WHERE Username = @username AND Password = @password";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", request.Username.Trim());
                    cmd.Parameters.AddWithValue("@password", request.Password.Trim());

                    conn.Open();
                    var result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string role = result.ToString().Trim();
                        return Ok(new LoginResponse
                        {
                            Success = true,
                            Role = role,
                            Message = "Login successful"
                        });
                    }
                    else
                    {
                        return Unauthorized(new LoginResponse
                        {
                            Success = false,
                            Role = null,
                            Message = "Invalid username or password"
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new LoginResponse
                {
                    Success = false,
                    Role = null,
                    Message = $"Internal server error: {ex.Message}"
                });
            }
        }
    }
}
