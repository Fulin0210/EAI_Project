﻿using System;
using System.Collections.Generic;
using System.Data;
using ClientBookingApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace ClientBookingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientBookingController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ClientBookingController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("clientBooking")]
        public IActionResult ClientBooking([FromBody] ClientBooking clientBooking)
        {
            try
            {
                // Optional: Validate enum
                if (!Enum.IsDefined(typeof(EventType), clientBooking.EventType))
                {
                    return BadRequest(new { status = "error", message = "Invalid EventType. Allowed values: 'Physical', 'Virtual'." });
                }

                string connectionString = _configuration.GetConnectionString("ATAGCons");

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"
                        INSERT INTO ClientBooking 
                        (ClientName, Email, Phone, EventType, EventDate, EventDescription, EventName, BookingDate, BookingStatus)
                        VALUES 
                        (@ClientName, @Email, @Phone, @EventType, @EventDate, @EventDescription, @EventName, GETDATE(), @BookingStatus)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add("@ClientName", SqlDbType.NVarChar, 100).Value = clientBooking.ClientName;
                        cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 100).Value = clientBooking.Email;
                        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 20).Value = (object)clientBooking.Phone ?? DBNull.Value;
                        cmd.Parameters.Add("@EventType", SqlDbType.NVarChar, 20).Value = clientBooking.EventType.ToString();
                        cmd.Parameters.Add("@EventDate", SqlDbType.DateTime).Value = clientBooking.EventDate;
                        cmd.Parameters.Add("@EventDescription", SqlDbType.NVarChar, -1).Value = (object)clientBooking.EventDescription ?? DBNull.Value;
                        cmd.Parameters.Add("@EventName", SqlDbType.NVarChar, 200).Value = clientBooking.EventName;
                        cmd.Parameters.Add("@BookingStatus", SqlDbType.NVarChar, 20).Value = clientBooking.BookingStatus.ToString();

                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            return Ok(new { status = "success", message = "Booking inserted successfully." });
                        else
                            return BadRequest(new { status = "error", message = "Failed to insert booking." });
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { status = "error", message = ex.Message });
            }
        }

        [HttpGet]
        [Route("allBookings")]
        public IActionResult GetAllBookings()
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("ATAGCons");
                var bookings = new List<ClientBooking>();

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"
                        SELECT BookingID, ClientName, Email, Phone, EventType, EventDate, EventDescription, EventName, BookingDate, BookingStatus
                        FROM ClientBooking";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var booking = new ClientBooking
                                {
                                    BookingID = reader.GetInt32(reader.GetOrdinal("BookingID")),
                                    ClientName = reader.GetString(reader.GetOrdinal("ClientName")),
                                    Email = reader.GetString(reader.GetOrdinal("Email")),
                                    Phone = reader.IsDBNull(reader.GetOrdinal("Phone")) ? null : reader.GetString(reader.GetOrdinal("Phone")),
                                    EventType = Enum.Parse<EventType>(reader.GetString(reader.GetOrdinal("EventType")), ignoreCase: true),
                                    EventDate = reader.GetDateTime(reader.GetOrdinal("EventDate")),
                                    EventDescription = reader.IsDBNull(reader.GetOrdinal("EventDescription")) ? null : reader.GetString(reader.GetOrdinal("EventDescription")),
                                    EventName = reader.GetString(reader.GetOrdinal("EventName")),
                                    BookingDate = reader.GetDateTime(reader.GetOrdinal("BookingDate")),
                                    BookingStatus = Enum.Parse<BookingStatus>(reader.GetString(reader.GetOrdinal("BookingStatus")), ignoreCase: true)
                                };
                                bookings.Add(booking);
                            }
                        }
                    }
                }

                return Ok(bookings);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { status = "error", message = ex.Message });
            }
        }
    }
}
