﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace ClientBookingInterface
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private static readonly HttpClient httpClient = new HttpClient
        {
            BaseAddress = new Uri("https://localhost:44339/")
        };
        public class LoginResponse
        {
            public bool Success { get; set; }
            public string Role { get; set; }
            public string Message { get; set; }
        }

        private async Task<(bool Success, string Role, string Message)> LoginUserAsync(string username, string password)
        {
            var loginData = new
            {
                Username = username,
                Password = password
            };

            var json = JsonConvert.SerializeObject(loginData);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync("api/users/login", content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var loginResponse = JsonConvert.DeserializeObject<LoginResponse>(responseContent);
                    return (loginResponse.Success, loginResponse.Role, loginResponse.Message);
                }
                else
                {
                    var errorResponse = JsonConvert.DeserializeObject<LoginResponse>(responseContent);
                    return (false, null, errorResponse?.Message ?? "Login failed.");
                }
            }
            catch (Exception ex)
            {
                return (false, null, "API error: " + ex.Message);
            }
        }
        private async void loginBtn_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var result = await LoginUserAsync(username, password);

            if (result.Success)
            {
                this.Hide();

                string role = result.Role?.Trim().ToLowerInvariant();

                if (role == "Sales")
                {
                    new CalendarView(role).Show();
                }
                else if (role == "Operations")
                {
                    new CalendarView(role).Show();
                }
                else
                {
                    new CalendarView(result.Role ?? "Guest").Show();
                }
            }
            else
            {
                MessageBox.Show(result.Message, "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e) { }

        private void label1_Click(object sender, EventArgs e) { }

        private void LoginForm_Load(object sender, EventArgs e) { }
    }
}
