﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace ClientBookingInterface
{
    public partial class CalendarView : Form
    {
        public static int _year, _month;
        private string _role;

        public CalendarView()
        {
            InitializeComponent();
            InitializeCalendar();
        }

        public CalendarView(string role)
        {
            InitializeComponent();
            _role = role;
            InitializeCalendar();
        }

        private void InitializeCalendar()
        {
            this.Load += CalendarView_Load;
            button1.Click += button1_Click;
            button2.Click += button2_Click;
        }

        private async void CalendarView_Load(object sender, EventArgs e)
        {
            _year = DateTime.Now.Year;
            _month = DateTime.Now.Month;

            MessageBox.Show("You are logged in as: " + _role);

            var bookings = await LoadBookingsFromApiAsync(_role);
            ShowDays(_month, _year, bookings);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            _month--;
            if (_month < 1)
            {
                _month = 12;
                _year--;
            }

            var bookings = await LoadBookingsFromApiAsync(_role);
            ShowDays(_month, _year, bookings);
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            _month++;
            if (_month > 12)
            {
                _month = 1;
                _year++;
            }

            var bookings = await LoadBookingsFromApiAsync(_role);
            ShowDays(_month, _year, bookings);
        }

        private async Task<List<ClientBooking>> LoadBookingsFromApiAsync(string role)
        {
            var bookings = new List<ClientBooking>();

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44339/");

                try
                {
                    var response = await client.GetAsync($"api/calendarview/bookings?role={role}");

                    response.EnsureSuccessStatusCode();

                    string json = await response.Content.ReadAsStringAsync();
                    bookings = JsonConvert.DeserializeObject<List<ClientBooking>>(json);
                    MessageBox.Show($"Received {bookings.Count} bookings from API.");

                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("API connection error:\n" + ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unexpected error:\n" + ex.ToString(), "Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return bookings;
        }

        private void ShowDays(int month, int year, List<ClientBooking> bookings)
        {
            flowLayoutPanel.SuspendLayout();
            flowLayoutPanel.Controls.Clear();

            string monthName = new DateTimeFormatInfo().GetMonthName(month);
            lbMonth.Text = $"{monthName.ToUpper()} {year}";

            DateTime startOfMonth = new DateTime(year, month, 1);
            int daysInMonth = DateTime.DaysInMonth(year, month);
            int startDayOfWeek = (int)startOfMonth.DayOfWeek;

            for (int i = 0; i < startDayOfWeek; i++)
            {
                ucDays pad = new ucDays("", new List<ClientBooking>(), _role);
                pad.Margin = new Padding(2);
                flowLayoutPanel.Controls.Add(pad);
            }

            for (int day = 1; day <= daysInMonth; day++)
            {
                DateTime currentDate = new DateTime(year, month, day);
                var dayBookings = bookings.Where(b => b.EventDate.Date == currentDate.Date).ToList();

                ucDays box = new ucDays(day.ToString(), dayBookings, _role);
                box.Margin = new Padding(2);
                flowLayoutPanel.Controls.Add(box);
            }

            int totalBoxes = startDayOfWeek + daysInMonth;
            int extraBoxes = (7 - (totalBoxes % 7)) % 7;

            for (int i = 0; i < extraBoxes; i++)
            {
                ucDays pad = new ucDays("", new List<ClientBooking>(), _role);
                pad.Margin = new Padding(2);
                flowLayoutPanel.Controls.Add(pad);
            }

            flowLayoutPanel.ResumeLayout();
        }

        private void lbMonth_Click(object sender, EventArgs e) { }
        private void flowLayoutPanel_Paint(object sender, PaintEventArgs e) { }
        private void panel5_Paint(object sender, PaintEventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void CalendarView_Load_1(object sender, EventArgs e) { }
    }
}
