﻿namespace ClientBookingInterface
{
    partial class SalesUpdateBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEventName = new System.Windows.Forms.Label();
            this.lblEventDate = new System.Windows.Forms.Label();
            this.lblClientName = new System.Windows.Forms.Label();
            this.lblEventDescription = new System.Windows.Forms.Label();
            this.eventStatusBox = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblEventType = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblEventStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblEventName
            // 
            this.lblEventName.AutoSize = true;
            this.lblEventName.Location = new System.Drawing.Point(42, 183);
            this.lblEventName.Name = "lblEventName";
            this.lblEventName.Size = new System.Drawing.Size(84, 16);
            this.lblEventName.TabIndex = 0;
            this.lblEventName.Text = "Event Name:";
            this.lblEventName.Click += new System.EventHandler(this.lblEventName_Click);
            // 
            // lblEventDate
            // 
            this.lblEventDate.AutoSize = true;
            this.lblEventDate.Location = new System.Drawing.Point(329, 183);
            this.lblEventDate.Name = "lblEventDate";
            this.lblEventDate.Size = new System.Drawing.Size(76, 16);
            this.lblEventDate.TabIndex = 1;
            this.lblEventDate.Text = "Event Date:";
            this.lblEventDate.Click += new System.EventHandler(this.lblEventDate_Click);
            // 
            // lblClientName
            // 
            this.lblClientName.AutoSize = true;
            this.lblClientName.Location = new System.Drawing.Point(42, 121);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(83, 16);
            this.lblClientName.TabIndex = 2;
            this.lblClientName.Text = "Client Name:";
            this.lblClientName.Click += new System.EventHandler(this.lblClientName_Click);
            // 
            // lblEventDescription
            // 
            this.lblEventDescription.AutoSize = true;
            this.lblEventDescription.Location = new System.Drawing.Point(42, 261);
            this.lblEventDescription.Name = "lblEventDescription";
            this.lblEventDescription.Size = new System.Drawing.Size(115, 16);
            this.lblEventDescription.TabIndex = 4;
            this.lblEventDescription.Text = "Event Description:";
            this.lblEventDescription.Click += new System.EventHandler(this.lblEventDescription_Click);
            // 
            // eventStatusBox
            // 
            this.eventStatusBox.FormattingEnabled = true;
            this.eventStatusBox.Location = new System.Drawing.Point(244, 346);
            this.eventStatusBox.Name = "eventStatusBox";
            this.eventStatusBox.Size = new System.Drawing.Size(221, 24);
            this.eventStatusBox.TabIndex = 7;
            this.eventStatusBox.SelectedIndexChanged += new System.EventHandler(this.eventStatusBox_SelectedIndexChanged);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(244, 409);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(221, 28);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(329, 121);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(100, 16);
            this.lblPhone.TabIndex = 9;
            this.lblPhone.Text = "Phone Number:";
            this.lblPhone.Click += new System.EventHandler(this.lblPhone_Click);
            // 
            // lblEventType
            // 
            this.lblEventType.AutoSize = true;
            this.lblEventType.Location = new System.Drawing.Point(329, 261);
            this.lblEventType.Name = "lblEventType";
            this.lblEventType.Size = new System.Drawing.Size(79, 16);
            this.lblEventType.TabIndex = 10;
            this.lblEventType.Text = "Event Type:";
            this.lblEventType.Click += new System.EventHandler(this.lblEventType_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(92, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(445, 39);
            this.label1.TabIndex = 11;
            this.label1.Text = "Client Booking Management";
            // 
            // lblEventStatus
            // 
            this.lblEventStatus.AutoSize = true;
            this.lblEventStatus.Location = new System.Drawing.Point(131, 349);
            this.lblEventStatus.Name = "lblEventStatus";
            this.lblEventStatus.Size = new System.Drawing.Size(84, 16);
            this.lblEventStatus.TabIndex = 12;
            this.lblEventStatus.Text = "Event Status:";
            // 
            // SalesUpdateBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(649, 491);
            this.Controls.Add(this.lblEventStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblEventType);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.eventStatusBox);
            this.Controls.Add(this.lblEventDescription);
            this.Controls.Add(this.lblClientName);
            this.Controls.Add(this.lblEventDate);
            this.Controls.Add(this.lblEventName);
            this.Name = "SalesUpdateBooking";
            this.Text = "SalesUpdateBooking";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEventName;
        private System.Windows.Forms.Label lblEventDate;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.Label lblEventDescription;
        private System.Windows.Forms.ComboBox eventStatusBox;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblEventType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEventStatus;
    }
}