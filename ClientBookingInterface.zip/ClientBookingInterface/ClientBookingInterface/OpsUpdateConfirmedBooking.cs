﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace ClientBookingInterface
{
    public partial class OpsUpdateConfirmedBooking : Form
    {
        private readonly int _bookingId;

        public OpsUpdateConfirmedBooking(int bookingId)
        {
            InitializeComponent();
            _bookingId = bookingId;
            LoadEventTypeOptions();
            _ = LoadEventBookingDetailsAsync();
        }

        private void LoadEventTypeOptions()
        {
            cmbEventType.Items.Clear();
            foreach (var type in Enum.GetValues(typeof(EventType)))
            {
                cmbEventType.Items.Add(type.ToString());
            }
        }

        private async Task LoadEventBookingDetailsAsync()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44339/");

            try
            {
                var response = await client.GetAsync($"api/operations/eventbooking/{_bookingId}");
                if (!response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Failed to load booking.");
                    Close();
                    return;
                }

                var json = await response.Content.ReadAsStringAsync();
                var booking = JsonConvert.DeserializeObject<EventBookingResponse>(json);

                if (booking == null)
                {
                    MessageBox.Show("Booking not found.");
                    Close();
                    return;
                }

                lblClientName.Text = $"Client Name: {booking.ClientName}";
                lblEmailAdd.Text = $"Email Address: {booking.Email}";
                lblPhone.Text = $"Phone Number: {booking.Phone ?? "-"}";
                txtEventName.Text = booking.EventName;
                cmbEventType.SelectedItem = booking.EventType;
                dateEvent.Value = booking.EventDate;
                txtEventDescription.Text = booking.EventDescription ?? "";
                txtNumOfPax.Text = booking.NumOfPax?.ToString() ?? "";
                txtEventLocation.Text = booking.EventLocation ?? "";
                txtAssignPIC.Text = booking.AssignedPIC ?? "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading booking:\n" + ex.Message);
            }
            finally
            {
                client.Dispose();
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var updatedBooking = new EventBookingUpdate
            {
                EventName = txtEventName.Text,
                EventType = cmbEventType.SelectedItem?.ToString() ?? "Physical",
                EventDate = dateEvent.Value,
                EventDescription = txtEventDescription.Text,
                NumOfPax = int.TryParse(txtNumOfPax.Text, out int pax) ? pax : (int?)null,
                EventLocation = string.IsNullOrWhiteSpace(txtEventLocation.Text) ? null : txtEventLocation.Text,
                AssignedPIC = string.IsNullOrWhiteSpace(txtAssignPIC.Text) ? null : txtAssignPIC.Text
            };

            var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44339/");
            var json = JsonConvert.SerializeObject(updatedBooking);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                var response = await client.PutAsync($"api/operations/updatebooking/{_bookingId}", content);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Booking updated successfully.");
                    Close();
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to update booking.\n{response.ReasonPhrase}\n{error}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating booking:\n" + ex.Message);
            }
            finally
            {
                client.Dispose();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}