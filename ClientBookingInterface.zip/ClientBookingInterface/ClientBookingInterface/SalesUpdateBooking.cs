﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;


namespace ClientBookingInterface
{
    public partial class SalesUpdateBooking : Form
    {
        private ClientBooking currentBooking;
        public SalesUpdateBooking(ClientBooking booking)
        {
            InitializeComponent();
            currentBooking = booking;
            LoadBookingDetails();
        }

        private void LoadBookingDetails()
        {
            eventStatusBox.Items.Clear();
            foreach (var status in Enum.GetValues(typeof(BookingStatus)))
            {
                eventStatusBox.Items.Add(status.ToString());
            }

            eventStatusBox.SelectedItem = currentBooking.BookingStatus.ToString();

            lblClientName.Text = $"Client Name: {currentBooking.ClientName}";
            lblPhone.Text = $"Phone Number: {currentBooking.Phone}";
            lblEventName.Text = $"Event Name: {currentBooking.EventName}";
            lblEventDescription.Text = $"Description: {currentBooking.EventDescription}";
            lblEventDate.Text = $"Date: {currentBooking.EventDate:yyyy-MM-dd}";
            lblEventType.Text = $"Type: {currentBooking.EventType}";
        }

        private void lblEventName_Click(object sender, EventArgs e) { }
        private void lblClientName_Click(object sender, EventArgs e) { }
        private void lblEventDescription_Click(object sender, EventArgs e) { }
        private void lblPhone_Click(object sender, EventArgs e) { }
        private void lblEventDate_Click(object sender, EventArgs e) { }
        private void lblEventType_Click(object sender, EventArgs e) { }
        private void eventStatusBox_SelectedIndexChanged(object sender, EventArgs e) { }
        private async void btnSave_Click(object sender, EventArgs e)
        {
            string selectedStatus = eventStatusBox.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedStatus))
            {
                MessageBox.Show("Please select a booking status.");
                return;
            }

            currentBooking.BookingStatus = (BookingStatus)Enum.Parse(typeof(BookingStatus), selectedStatus);

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44339/");

                try
                {
                    if (currentBooking.BookingStatus == BookingStatus.Cancelled)
                    {
                        var deleteResponse = await client.DeleteAsync($"api/sales/cancel/{currentBooking.BookingID}");

                        if (deleteResponse.IsSuccessStatusCode)
                        {
                            MessageBox.Show("Booking is cancelled and removed.");
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Failed to cancel booking: " + deleteResponse.ReasonPhrase);
                        }
                    }
                    else if (currentBooking.BookingStatus == BookingStatus.Confirmed)
                    {
                        var statusUpdate = new { status = currentBooking.BookingStatus };
                        var statusJson = JsonConvert.SerializeObject(statusUpdate);
                        var statusContent = new StringContent(statusJson, Encoding.UTF8, "application/json");

                        var updateResponse = await client.PutAsync(
                            $"api/sales/update-status/{currentBooking.BookingID}", statusContent);

                        if (!updateResponse.IsSuccessStatusCode)
                        {
                            MessageBox.Show("Failed to update status: " + updateResponse.ReasonPhrase);
                            return;
                        }

                        // Confirm booking (insert into EventBooking)
                        var confirmJson = JsonConvert.SerializeObject(currentBooking);
                        var confirmContent = new StringContent(confirmJson, Encoding.UTF8, "application/json");

                        var confirmResponse = await client.PostAsync("api/sales/confirm", confirmContent);

                        if (confirmResponse.IsSuccessStatusCode)
                        {
                            MessageBox.Show("Booking is confirmed and saved to EventBooking.");
                            this.Close();
                        }
                        else
                        {
                            string errorDetail = await confirmResponse.Content.ReadAsStringAsync();
                            MessageBox.Show("Failed to confirm booking:\n" + errorDetail);
                        }
                    }
                    else
                    {
                        // Only update status, no need to touch EventBooking
                        var statusContent = new StringContent(
                            $"\"{currentBooking.BookingStatus}\"", Encoding.UTF8, "application/json");

                        var updateResponse = await client.PutAsync(
                            $"api/sales/update-status/{currentBooking.BookingID}", statusContent);

                        if (updateResponse.IsSuccessStatusCode)
                        {
                            MessageBox.Show("Booking status updated.");
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update booking status: " + updateResponse.ReasonPhrase);
                        }
                    }
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show("API connection error:\n" + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unexpected error:\n" + ex.ToString());
                }
            }
        }
    }
}
