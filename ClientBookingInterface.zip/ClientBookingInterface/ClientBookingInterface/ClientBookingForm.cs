﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace ClientBookingInterface
{
    public partial class ClientBookingForm : Form
    {
        public ClientBookingForm()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            comboEventType.Items.AddRange(new string[]
            {
                "Virtual",
                "Physical"
            });
            comboEventType.SelectedIndex = 0; // default
        }

        private void dtpEventDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = dtpEventDate.Value;
            if (selectedDate.Date < DateTime.Today)
            {
                MessageBox.Show("You cannot select a past date!", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpEventDate.Value = DateTime.Today;
            }
        }
        public async Task<List<ClientBooking>> GetBookingsAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44339/");
                var response = await client.GetAsync("api/ClientBooking/allBookings");
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync();
                var bookings = JsonConvert.DeserializeObject<List<ClientBooking>>(json);
                return bookings;
            }
        }
        private async void btnSubmit_Click(object sender, EventArgs e)
        {
            var booking = new
            {
                ClientName = txtName.Text,
                Email = txtEmail.Text,
                Phone = txtPhone.Text,
                EventType = comboEventType.SelectedItem?.ToString(),
                EventDate = dtpEventDate.Value,
                EventName = txtEventName.Text,
                EventDescription = txtEventDescription.Text,
                BookingStatus = "Pending"
            };

            var json = JsonConvert.SerializeObject(booking);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44339/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var content = new StringContent(json, Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync("api/ClientBooking/clientBooking", content);
                    var responseContent = await response.Content.ReadAsStringAsync();

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show(
                            "Booking has been made. Thank you for booking with us!",
                            "Success",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                    else
                    {
                        MessageBox.Show(
                            $"Booking failed.\n\n{responseContent}",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label8_Click(object sender, EventArgs e) { }
        private void txtName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e) { }
    }
}