﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ClientBookingInterface
{
    public partial class ucDays : UserControl
    {
        private string _day;
        private string _role;
        public ClientBooking Booking { get; set; }

        private List<ClientBooking> _bookings;

        public ucDays(string day, List<ClientBooking> bookings, string role = "")
        {
            InitializeComponent();
            label1.Text = day;
            _day = day;
            _role = role;
            _bookings = bookings;

            if (_bookings != null && _bookings.Count > 0)
            {
                flowLayoutPanel1.Visible = true;
                flowLayoutPanel1.Controls.Clear();

                foreach (var booking in _bookings)
                {
                    if (_role == "Operations" && booking.BookingStatus != BookingStatus.Confirmed)
                        continue;

                    Panel eventPanel = new Panel
                    {
                        BackColor = Color.LightGreen,
                        Height = 25,
                        Width = flowLayoutPanel1.Width - 10,
                        Margin = new Padding(2),
                        Tag = booking
                    };

                    eventPanel.MouseEnter += (s, e) => eventPanel.BackColor = Color.LightSkyBlue;
                    eventPanel.MouseLeave += (s, e) => eventPanel.BackColor = Color.LightGreen;

                    eventPanel.Click += EventPanel_Click;

                    Label eventLabel = new Label
                    {
                        Text = (_role == "Sales")
                            ? $"{booking.EventName} ({booking.BookingStatus})"
                            : booking.EventName,
                        Dock = DockStyle.Fill,
                        TextAlign = ContentAlignment.MiddleLeft,
                        Font = new Font("Segoe UI", 8),
                        AutoSize = false
                    };

                    eventLabel.Click += EventPanel_Click;

                    eventPanel.Controls.Add(eventLabel);
                    flowLayoutPanel1.Controls.Add(eventPanel);
                }

            }
        }

        private void EventPanel_Click(object sender, EventArgs e)
        {
            Control clickedControl = sender as Control;

            Panel eventPanel = clickedControl as Panel ?? clickedControl.Parent as Panel;

            if (eventPanel?.Tag is ClientBooking booking)
            {
                if (_role == "Sales")
                {
                    SalesUpdateBooking salesForm = new SalesUpdateBooking(booking);
                    salesForm.ShowDialog();
                }
                else if (_role == "Operations")
                {
                    OpsUpdateConfirmedBooking opsForm = new OpsUpdateConfirmedBooking(booking.BookingID);
                    opsForm.ShowDialog();
                }
            }
        }

        private void ucDays_Load(object sender, EventArgs e)
        {
            if (_day == DateTime.Now.Day.ToString() &&
                CalendarView._month == DateTime.Now.Month &&
                CalendarView._year == DateTime.Now.Year)
            {
                panel1.BackColor = Color.LightBlue;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
