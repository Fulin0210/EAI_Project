﻿namespace ClientBookingInterface
{
    partial class OpsUpdateConfirmedBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblEventType = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblEventDescription = new System.Windows.Forms.Label();
            this.lblClientName = new System.Windows.Forms.Label();
            this.lblEventDate = new System.Windows.Forms.Label();
            this.lblEventName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblEmailAdd = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtEventName = new System.Windows.Forms.MaskedTextBox();
            this.txtEventDescription = new System.Windows.Forms.MaskedTextBox();
            this.txtNumOfPax = new System.Windows.Forms.MaskedTextBox();
            this.txtEventLocation = new System.Windows.Forms.MaskedTextBox();
            this.txtAssignPIC = new System.Windows.Forms.MaskedTextBox();
            this.dateEvent = new System.Windows.Forms.DateTimePicker();
            this.cmbEventType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(145, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(445, 39);
            this.label1.TabIndex = 21;
            this.label1.Text = "Client Booking Management";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblEventType
            // 
            this.lblEventType.AutoSize = true;
            this.lblEventType.Location = new System.Drawing.Point(406, 307);
            this.lblEventType.Name = "lblEventType";
            this.lblEventType.Size = new System.Drawing.Size(79, 16);
            this.lblEventType.TabIndex = 20;
            this.lblEventType.Text = "Event Type:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(30, 152);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(100, 16);
            this.lblPhone.TabIndex = 19;
            this.lblPhone.Text = "Phone Number:";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(537, 494);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(178, 26);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblEventDescription
            // 
            this.lblEventDescription.AutoSize = true;
            this.lblEventDescription.Location = new System.Drawing.Point(32, 307);
            this.lblEventDescription.Name = "lblEventDescription";
            this.lblEventDescription.Size = new System.Drawing.Size(115, 16);
            this.lblEventDescription.TabIndex = 16;
            this.lblEventDescription.Text = "Event Description:";
            // 
            // lblClientName
            // 
            this.lblClientName.AutoSize = true;
            this.lblClientName.Location = new System.Drawing.Point(30, 118);
            this.lblClientName.Name = "lblClientName";
            this.lblClientName.Size = new System.Drawing.Size(83, 16);
            this.lblClientName.TabIndex = 15;
            this.lblClientName.Text = "Client Name:";
            // 
            // lblEventDate
            // 
            this.lblEventDate.AutoSize = true;
            this.lblEventDate.Location = new System.Drawing.Point(406, 270);
            this.lblEventDate.Name = "lblEventDate";
            this.lblEventDate.Size = new System.Drawing.Size(76, 16);
            this.lblEventDate.TabIndex = 14;
            this.lblEventDate.Text = "Event Date:";
            // 
            // lblEventName
            // 
            this.lblEventName.AutoSize = true;
            this.lblEventName.Location = new System.Drawing.Point(32, 270);
            this.lblEventName.Name = "lblEventName";
            this.lblEventName.Size = new System.Drawing.Size(84, 16);
            this.lblEventName.TabIndex = 13;
            this.lblEventName.Text = "Event Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 380);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Number of Pax:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(406, 377);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Event Location:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 417);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 16);
            this.label4.TabIndex = 25;
            this.label4.Text = "Assigned PIC:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(28, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 25);
            this.label5.TabIndex = 26;
            this.label5.Text = "Client Information";
            // 
            // lblEmailAdd
            // 
            this.lblEmailAdd.AutoSize = true;
            this.lblEmailAdd.Location = new System.Drawing.Point(406, 118);
            this.lblEmailAdd.Name = "lblEmailAdd";
            this.lblEmailAdd.Size = new System.Drawing.Size(98, 16);
            this.lblEmailAdd.TabIndex = 27;
            this.lblEmailAdd.Text = "Email Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(30, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 25);
            this.label6.TabIndex = 28;
            this.label6.Text = "Event Information";
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(165, 267);
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(179, 22);
            this.txtEventName.TabIndex = 29;
            // 
            // txtEventDescription
            // 
            this.txtEventDescription.Location = new System.Drawing.Point(165, 307);
            this.txtEventDescription.Name = "txtEventDescription";
            this.txtEventDescription.Size = new System.Drawing.Size(179, 22);
            this.txtEventDescription.TabIndex = 30;
            // 
            // txtNumOfPax
            // 
            this.txtNumOfPax.Location = new System.Drawing.Point(165, 377);
            this.txtNumOfPax.Margin = new System.Windows.Forms.Padding(0);
            this.txtNumOfPax.Name = "txtNumOfPax";
            this.txtNumOfPax.Size = new System.Drawing.Size(179, 22);
            this.txtNumOfPax.TabIndex = 31;
            // 
            // txtEventLocation
            // 
            this.txtEventLocation.Location = new System.Drawing.Point(536, 374);
            this.txtEventLocation.Margin = new System.Windows.Forms.Padding(0);
            this.txtEventLocation.Name = "txtEventLocation";
            this.txtEventLocation.Size = new System.Drawing.Size(179, 22);
            this.txtEventLocation.TabIndex = 32;
            // 
            // txtAssignPIC
            // 
            this.txtAssignPIC.Location = new System.Drawing.Point(165, 417);
            this.txtAssignPIC.Margin = new System.Windows.Forms.Padding(0);
            this.txtAssignPIC.Name = "txtAssignPIC";
            this.txtAssignPIC.Size = new System.Drawing.Size(179, 22);
            this.txtAssignPIC.TabIndex = 33;
            // 
            // dateEvent
            // 
            this.dateEvent.Location = new System.Drawing.Point(536, 267);
            this.dateEvent.Name = "dateEvent";
            this.dateEvent.Size = new System.Drawing.Size(179, 22);
            this.dateEvent.TabIndex = 34;
            // 
            // cmbEventType
            // 
            this.cmbEventType.FormattingEnabled = true;
            this.cmbEventType.Location = new System.Drawing.Point(536, 307);
            this.cmbEventType.Name = "cmbEventType";
            this.cmbEventType.Size = new System.Drawing.Size(179, 24);
            this.cmbEventType.TabIndex = 35;
            // 
            // OpsUpdateConfirmedBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 532);
            this.Controls.Add(this.cmbEventType);
            this.Controls.Add(this.dateEvent);
            this.Controls.Add(this.txtAssignPIC);
            this.Controls.Add(this.txtEventLocation);
            this.Controls.Add(this.txtNumOfPax);
            this.Controls.Add(this.txtEventDescription);
            this.Controls.Add(this.txtEventName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblEmailAdd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblEventType);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblEventDescription);
            this.Controls.Add(this.lblClientName);
            this.Controls.Add(this.lblEventDate);
            this.Controls.Add(this.lblEventName);
            this.Name = "OpsUpdateConfirmedBooking";
            this.Text = "OpsUpdateConfirmedBooking";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEventType;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblEventDescription;
        private System.Windows.Forms.Label lblClientName;
        private System.Windows.Forms.Label lblEventDate;
        private System.Windows.Forms.Label lblEventName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblEmailAdd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox txtEventName;
        private System.Windows.Forms.MaskedTextBox txtEventDescription;
        private System.Windows.Forms.MaskedTextBox txtNumOfPax;
        private System.Windows.Forms.MaskedTextBox txtEventLocation;
        private System.Windows.Forms.MaskedTextBox txtAssignPIC;
        private System.Windows.Forms.DateTimePicker dateEvent;
        private System.Windows.Forms.ComboBox cmbEventType;
    }
}